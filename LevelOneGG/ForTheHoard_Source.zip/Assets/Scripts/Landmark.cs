﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Landmark : MonoBehaviour
{

    // Start is called before the first frame update


    private void Awake()
    {
        //ContentType = TileContentType.Landmark;
    }

    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
